void main() {
     TRISB=0x00;
     PORTB=0x00;
     while(1){
         portb.f0=1;
         delay_ms(200);
         portb.f0=0;
         delay_ms(200);
     }
}