unsigned char hexvalue[10] = {
  0x3F,
  0x06,
  0x5B,
  0x4F,
  0x66,
  0x6D,
  0x7D,
  0x07,
  0x7F,
  0x6F
};
int i=0;
void main() {
     TRISB=0x00;
     PORTB=0x00;
     while(1){
         portb=hexvalue[i];
         i++;
         delay_ms(500);
         if(i>9){
             i=0;
         }
     }
}