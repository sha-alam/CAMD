int i;
char j[]={0b1000000,
0b0100000,
0b0010000,
0b0001000,
0b0000100,
0b0000010,
0b0000001,};
char k[]={0b11110,
0b10001,
0b10001,
0b11110,
0b10100,
0b10010,
0b10001};
void main() {
     TRISB=0x00;
     TRISC=0x00;
     while(1){
         for(i=0;i<7;i++){
             PORTC=j[i];
             PORTB=k[i];
             delay_ms(1);
         }
     }
}