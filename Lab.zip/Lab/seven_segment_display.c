void display();
//char array[]={0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};
char array[]={0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92, 0x82, 0xF8, 0x80, 0x90};
int i=0, leftDigit, rightDigit;
void main() {
    TRISB=0x00; //Set portb as output
    portb=0x00; //Initial off state
    TRISC=0x00; //Set portc as output
    portc=0x00; //Initial off state
    TRISD=0xff; //Set portd as input
    while(1)
    {
        display();
        //Code Section for increment
        if(portd.f0==1)
        {
             delay_ms(100);
             if(portd.f0==1)
             {
                  if(i<99)
                     i=i+1;
             }
        }
        //Code Section for decrement
        if(portd.f1==1)
        {
             delay_ms(100);
             if(portd.f1==1)
             {
                  if(i>0)
                     i=i-1;
             }
        }

    }
}
void display()
{
    leftDigit=i/10;
    rightDigit=i%10;
    portb=array[leftDigit];
    portc.f0=1;
    delay_ms(10);
    portc.f0=0;
    portb=array[rightDigit];
    portc.f1=1;
    delay_ms(10);
    portc.f1=0;
}