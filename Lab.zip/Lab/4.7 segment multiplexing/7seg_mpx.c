unsigned char hexvalue[10] = {
  0x3F,
  0x06,
  0x5B,
  0x4F,
  0x66,
  0x6D,
  0x7D,
  0x07,
  0x7F,
  0x6F
};
int i,j,rxz=0,q;
void main() {
    TRISB=0x00;
    TRISD=0x00;
    while(1){
    for(j=0;j<10;j++){
     for(q=0;q<10;q++){
        for(i=0;i<25;i++){
            portb=hexvalue[j];
            portd.f0=0;
            delay_ms(10);
            portd.f0=1;
            portb=hexvalue[q];
            portd.f1=0;
            delay_ms(10);
            portd.f1=1;
            }

        }
        }
    }
}