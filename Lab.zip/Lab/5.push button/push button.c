char flag=0;
void main() {
     TRISB=0x00;
     PORTB=0x00;
     TRISD=0xff;
     while(1){
         if(portd.f0==1){
             delay_ms(200);
             if(portd.f0==1){
                 if(flag==1){
                     flag=0;
                 }else{
                     flag=1;
                 }
             }
         }
         if(flag==1){
             portb.f0=1;
         }else{
             portb.f0=0;
         }
     }
}